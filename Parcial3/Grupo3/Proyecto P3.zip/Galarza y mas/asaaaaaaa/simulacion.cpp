// simulacion.cpp
#ifndef SIMULACION_CPP
#define SIMULACION_CPP

#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <limits>

using namespace std;

#include "usuario.cpp"
#include "edificio.cpp"
#include "automata.cpp"

struct ResultadoSimulacion {
    Estado estadoFinal;
    bool esValida;
    string razon;
    vector<pair<string, Estado>> trazaEstados;
};

inline ResultadoSimulacion evaluarSecuenciaAcciones(Usuario& usr, const Zona& zona, const vector<string>& acciones, bool mostrarDetalle) {
    Estado estadoActual = q0_FUERA;
    ResultadoSimulacion res;
    res.trazaEstados.push_back({"Inicio", q0_FUERA});

    if (mostrarDetalle) {
        cout << "\n-----------------------------------------------------\n";
        cout << "  EVALUACION DE SECUENCIA PARA: " << usr.nombre << "\n";
        cout << "  Ubicacion Previa: [" << usr.zonaActual << "]\n";
        cout << "  Destino Solicitado: " << zona.nombre << " (Nivel " << zona.nivel << " | Punto: " << zona.puntoControl.id << ")\n";
        cout << "-----------------------------------------------------\n";
        cout << "Estado Inicial: " << estadoToString(estadoActual) << "\n";
    }

    for (size_t i = 0; i < acciones.size(); i++) {
        string explicacion = "";
        Estado estadoAnterior = estadoActual;
        estadoActual = procesarTransicion(estadoActual, acciones[i], usr, zona, explicacion);
        res.trazaEstados.push_back({acciones[i], estadoActual});

        if (mostrarDetalle) {
            cout << "\n [Paso " << i + 1 << "] Accion: '" << acciones[i] << "'\n";
            cout << "  +-- Transicion: " << estadoToString(estadoAnterior) << " ==> " << estadoToString(estadoActual) << "\n";
            cout << "  +-- Detalle: " << explicacion << "\n";
        }

        if (estadoActual == qACEPTACION_DENTRO || estadoActual == qRECHAZO_DENEGADO) {
            res.razon = explicacion;
            break;
        }
    }

    res.estadoFinal = estadoActual;
    res.esValida = (estadoActual == qACEPTACION_DENTRO);

    if (res.esValida) {
        usr.zonaActual = zona.nombre;
    }

    if (mostrarDetalle) {
        cout << "\n-----------------------------------------------------\n";
        if (res.esValida) {
            cout << " [OK] RESULTADO: SECUENCIA VALIDA - ACCESO CONCEDIDO\n";
            cout << " [INFO] Ubicacion actual de " << usr.nombre << " actualizada a: [" << usr.zonaActual << "]\n";
        } else {
            cout << " [X] RESULTADO: SECUENCIA RECHAZADA / INVALIDA\n";
            cout << "     Razon: " << res.razon << "\n";
            cout << " [INFO] El usuario permanece en su ubicacion previo: [" << usr.zonaActual << "]\n";
        }
        cout << "-----------------------------------------------------\n";
    }

    return res;
}

inline void simularAccesoManual() {
    cout << "\n=====================================================\n";
    cout << "          SIMULACION INDIVIDUAL / MANUAL             \n";
    cout << "=====================================================\n";

    // 1. Seleccion de Usuario
    mostrarUsuarios();
    int opcUsuario;
    cout << "Seleccione el usuario (1-" << listaUsuarios.size() << "): ";
    cin >> opcUsuario;
    if (cin.fail() || opcUsuario < 1 || opcUsuario > (int)listaUsuarios.size()) {
        cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Seleccion de usuario invalida.\n";
        return;
    }

    // 2. Seleccion de Zona
    mostrarEdificio();
    int opcZona;
    cout << "Seleccione la Zona Destino (1-" << mapaEdificio.size() << "): ";
    cin >> opcZona;
    if (cin.fail() || opcZona < 1 || opcZona > (int)mapaEdificio.size()) {
        cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Seleccion de zona invalida.\n";
        return;
    }
    Zona zona = obtenerZonaPorId(opcZona);

    // 3. Seleccion de Modo de Entrada de Secuencia
    cout << "\nModo de Secuencia de Acciones:\n";
    cout << " 1. Secuencia Estandar (Identificarse -> Tarjeta -> Abrir_Puerta)\n";
    cout << " 2. Secuencia Biometrica (Identificarse -> Tarjeta -> Huella -> Abrir_Puerta)\n";
    cout << " 3. Secuencia Invalida por Salto de Pasos (Tarjeta -> Abrir_Puerta)\n";
    cout << " 4. Ingresar Secuencia Personalizada Accion por Accion\n";
    cout << "Opcion: ";
    int opcSec;
    cin >> opcSec;

    vector<string> acciones;
    if (opcSec == 1) {
        acciones = {"Identificarse", "Tarjeta", "Abrir_Puerta"};
    } else if (opcSec == 2) {
        acciones = {"Identificarse", "Tarjeta", "Huella", "Abrir_Puerta"};
    } else if (opcSec == 3) {
        acciones = {"Tarjeta", "Abrir_Puerta"};
    } else if (opcSec == 4) {
        cout << "\nIngreso de acciones (1: Identificarse | 2: Tarjeta | 3: Huella | 4: Abrir_Puerta | 0: Terminar):\n";
        int subOpc = -1;
        while (subOpc != 0) {
            cout << "Accion #" << acciones.size() + 1 << ": ";
            cin >> subOpc;
            if (cin.fail()) { cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n'); break; }
            if (subOpc == 1) acciones.push_back("Identificarse");
            else if (subOpc == 2) acciones.push_back("Tarjeta");
            else if (subOpc == 3) acciones.push_back("Huella");
            else if (subOpc == 4) acciones.push_back("Abrir_Puerta");
            else if (subOpc == 0) break;
        }
    } else {
        cout << "Opcion de secuencia no valida.\n";
        return;
    }

    evaluarSecuenciaAcciones(listaUsuarios[opcUsuario - 1], zona, acciones, true);
}

inline void ejecutarBateriaPruebas() {
    cout << "\n=====================================================\n";
    cout << "  PROCESAMIENTO DE MULTIPLES SECUENCIAS (PRUEBAS)    \n";
    cout << "=====================================================\n";
    cout << "Procesando bateria de secuencias esperadas e inesperadas...\n";

    struct CasoPrueba {
        string descripcion;
        Usuario usuario;
        Zona zona;
        vector<string> acciones;
        bool debeSerValida;
    };

    vector<CasoPrueba> casos = {
        {
            "Acceso Estandar Valido (Recepcion -> Pasillo Central)",
            listaUsuarios[1], // Ana (Empleado, en Recepcion)
            obtenerZonaPorId(2), // Pasillo Central (Nivel 1)
            {"Identificarse", "Tarjeta", "Abrir_Puerta"},
            true
        },
        {
            "Acceso Biometrico Valido (Oficinas -> Servidores)",
            listaUsuarios[2], // Laura (Tecnico, en Oficinas Administrativas)
            obtenerZonaPorId(5), // Servidores (Nivel 3)
            {"Identificarse", "Tarjeta", "Huella", "Abrir_Puerta"},
            true
        },
        {
            "Violacion de Flujo (Salto de Pasillo a Servidores/Boveda)",
            {"Ana (Empleado)", EMPLEADO, 2, false, "Pasillo Central"},
            obtenerZonaPorId(5), // Servidores (Nivel 3)
            {"Identificarse", "Tarjeta", "Abrir_Puerta"},
            false
        },
        {
            "Violacion de Secuencia (Salto de paso sin Identificarse)",
            listaUsuarios[1], // Ana
            obtenerZonaPorId(2), // Pasillo Central
            {"Tarjeta", "Abrir_Puerta"},
            false
        },
        {
            "Violacion de Permiso por Nivel (Visitante a Nivel 2)",
            {"Pedro (Visitante)", VISITANTE, 1, false, "Pasillo Central"},
            obtenerZonaPorId(3), // Oficinas (Nivel 2)
            {"Identificarse", "Tarjeta", "Abrir_Puerta"},
            false
        },
        {
            "Falta de Validacion Biometrica (Sin Huella en Nivel 3)",
            {"Carlos (Admin)", ADMINISTRADOR, 3, true, "Oficinas Administrativas"},
            obtenerZonaPorId(5), // Servidores (Nivel 3)
            {"Identificarse", "Tarjeta", "Abrir_Puerta"}, // Falta Huella
            false
        }
    };

    int correctos = 0;
    cout << "\n--------------------------------------------------------------------------------------------------\n";
    cout << left << setw(4) << "ID"
         << setw(55) << "Descripcion del Caso"
         << setw(20) << "Resultado"
         << setw(25) << "Estado Final" << "\n";
    cout << "--------------------------------------------------------------------------------------------------\n";

    for (size_t i = 0; i < casos.size(); i++) {
        ResultadoSimulacion res = evaluarSecuenciaAcciones(casos[i].usuario, casos[i].zona, casos[i].acciones, false);
        bool coincide = (res.esValida == casos[i].debeSerValida);
        if (coincide) correctos++;

        cout << left << setw(4) << (i + 1)
             << setw(55) << casos[i].descripcion
             << setw(20) << (res.esValida ? "[OK] ACEPTADA" : "[X] RECHAZADA")
             << setw(25) << estadoToString(res.estadoFinal) << "\n";
    }

    cout << "--------------------------------------------------------------------------------------------------\n";
    cout << "Resumen: " << correctos << " de " << casos.size() << " secuencias evaluadas con comportamiento esperado.\n";
    cout << "=====================================================\n";
}

#endif
