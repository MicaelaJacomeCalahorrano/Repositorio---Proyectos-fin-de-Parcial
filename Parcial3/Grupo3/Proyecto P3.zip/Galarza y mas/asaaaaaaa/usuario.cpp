// usuario.cpp
#ifndef USUARIO_CPP
#define USUARIO_CPP

#include <iostream>
#include <string>
#include <vector>
#include <limits>

using namespace std;

enum Rol {
    VISITANTE = 1,
    EMPLEADO = 2,
    TECNICO = 3,
    ADMINISTRADOR = 4
};

struct Usuario {
    string nombre;
    Rol rol;
    int nivelMaximoPermitido; // Nivel 1, 2 o 3
    bool tieneBiometria;
    string zonaActual; // Ubicacion actual del usuario en el edificio
};

inline string rolToString(Rol r) {
    switch(r) {
        case VISITANTE: return "Visitante";
        case EMPLEADO: return "Empleado";
        case TECNICO: return "Tecnico";
        case ADMINISTRADOR: return "Administrador";
        default: return "Desconocido";
    }
}

// Lista base de usuarios registrados en el sistema con su ubicacion actual
inline vector<Usuario> listaUsuarios = {
    {"Pedro (Visitante)", VISITANTE, 1, false, "Fuera del edificio"},
    {"Ana (Empleado)", EMPLEADO, 2, false, "Recepcion"},
    {"Laura (Tecnico)", TECNICO, 3, true, "Oficinas Administrativas"},
    {"Carlos (Admin)", ADMINISTRADOR, 3, true, "Fuera del edificio"}
};

inline void mostrarUsuarios() {
    cout << "\n=====================================================\n";
    cout << "      MATRIZ DE USUARIOS, PERMISOS Y UBICACION       \n";
    cout << "=====================================================\n";
    for(size_t i = 0; i < listaUsuarios.size(); i++) {
        cout << i + 1 << ". " << listaUsuarios[i].nombre 
             << " | Rol: " << rolToString(listaUsuarios[i].rol)
             << " | Nivel Max: " << listaUsuarios[i].nivelMaximoPermitido
             << " | Biometria: " << (listaUsuarios[i].tieneBiometria ? "Si" : "No")
             << " | Ubicacion Actual: [" << listaUsuarios[i].zonaActual << "]\n";
    }
    cout << "=====================================================\n";
}

inline void registrarNuevoUsuario() {
    cout << "\n=====================================================\n";
    cout << "             REGISTRO DE NUEVO USUARIO               \n";
    cout << "=====================================================\n";
    
    string nombre;
    cout << "Ingrese el nombre del usuario: ";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    getline(cin, nombre);

    if (nombre.empty()) {
        cout << "El nombre no puede estar vacio.\n";
        return;
    }

    cout << "\nSeleccione el Rol del Usuario:\n";
    cout << " 1. Visitante (Nivel Max 1)\n";
    cout << " 2. Empleado (Nivel Max 2)\n";
    cout << " 3. Tecnico (Nivel Max 3 con Biometria)\n";
    cout << " 4. Administrador (Acceso Total)\n";
    cout << "Opcion: ";
    int opcRol;
    cin >> opcRol;

    if (cin.fail() || opcRol < 1 || opcRol > 4) {
        cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Rol invalido. Cancelando registro.\n";
        return;
    }

    Rol rolSeleccionado = static_cast<Rol>(opcRol);
    
    int nivelMax = 1;
    if (rolSeleccionado == EMPLEADO) nivelMax = 2;
    else if (rolSeleccionado == TECNICO || rolSeleccionado == ADMINISTRADOR) nivelMax = 3;

    cout << "Nivel maximo asignado: " << nivelMax << "\n";

    cout << "¿Tiene registro de Huella Biometrica? (1: Si | 0: No): ";
    int opcBio;
    cin >> opcBio;
    bool tieneBio = (opcBio == 1);

    Usuario nuevoUsr = {nombre, rolSeleccionado, nivelMax, tieneBio, "Fuera del edificio"};
    listaUsuarios.push_back(nuevoUsr);

    cout << "\n[OK] Usuario '" << nombre << "' registrado exitosamente.\n";
}

#endif
