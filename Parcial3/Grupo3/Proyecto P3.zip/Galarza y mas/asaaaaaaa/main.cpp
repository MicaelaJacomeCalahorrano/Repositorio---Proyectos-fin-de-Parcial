// main.cpp
#include <iostream>
#include <string>
#include <vector>
#include <limits>

using namespace std;

#include "usuario.cpp"
#include "edificio.cpp"
#include "automata.cpp"
#include "simulacion.cpp"

int main() {
    int opcion = 0;
    
    while(opcion != 6) {
        cout << "\n=====================================================\n";
        cout << "  SISTEMA DE CONTROL DE ACCESO - EDIFICIO INTELIGENTE\n";
        cout << "=====================================================\n";
        cout << " 1. Mostrar Mapa del Edificio (Niveles, Zonas y Puntos)\n";
        cout << " 2. Mostrar Usuarios, Permisos y Ubicacion Actual\n";
        cout << " 3. Registrar Nuevo Usuario\n";
        cout << " 4. Simular Secuencia de Acceso (Manual / Paso a Paso)\n";
        cout << " 5. Ejecutar Bateria de Pruebas (Procesar Multiples Secuencias)\n";
        cout << " 6. Salir\n";
        cout << "=====================================================\n";
        cout << " Seleccione una opcion: ";
        cin >> opcion;

        if(cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Entrada invalida. Por favor introduzca un numero.\n";
            continue;
        }

        switch(opcion) {
            case 1:
                mostrarEdificio();
                break;
            case 2:
                mostrarUsuarios();
                break;
            case 3:
                registrarNuevoUsuario();
                break;
            case 4:
                simularAccesoManual();
                break;
            case 5:
                ejecutarBateriaPruebas();
                break;
            case 6:
                cout << "\nSaliendo del sistema de control de acceso...\n";
                break;
            default:
                cout << "\nOpcion no valida. Intente de nuevo.\n";
                break;
        }
    }
    
    return 0;
}
