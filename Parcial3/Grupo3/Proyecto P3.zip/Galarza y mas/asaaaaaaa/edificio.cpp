// edificio.cpp
#ifndef EDIFICIO_CPP
#define EDIFICIO_CPP

#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct PuntoControl {
    string id;
    string nombre;
    int nivelRequerido;
    bool requiereBiometria;
};

struct Zona {
    int id;
    string nombre;
    int nivel;
    PuntoControl puntoControl;
};

inline vector<Zona> mapaEdificio = {
    {1, "Recepcion", 1, {"PC-101", "Torniquete Entrada Principal", 1, false}},
    {2, "Pasillo Central", 1, {"PC-102", "Puerta Acceso Pasillo", 1, false}},
    {3, "Oficinas Administrativas", 2, {"PC-201", "Lector RFID Oficinas", 2, false}},
    {4, "Laboratorio I+D", 2, {"PC-202", "Lector RFID + Teclado Lab", 2, false}},
    {5, "Sala de Servidores", 3, {"PC-301", "Esclusa Biometrica Servidores", 3, true}}
};

inline void mostrarEdificio() {
    cout << "\n=====================================================\n";
    cout << "  ESTRUCTURA DEL EDIFICIO (NIVELES, ZONAS Y FLUJO)   \n";
    cout << "=====================================================\n";
    cout << "  [Fuera del edificio]\n";
    cout << "          |\n";
    cout << "          v\n";
    cout << "  [Nivel 1 - Acceso Publico y General]\n";
    cout << "    +-- Zona 1: Recepcion [PC-101 (Torniquete)]\n";
    cout << "          |\n";
    cout << "          v\n";
    cout << "    +-- Zona 2: Pasillo Central [PC-102 (Puerta Pasillo)]\n";
    cout << "          |\n";
    cout << "          +-----------------------+\n";
    cout << "          v                       v\n";
    cout << "  [Nivel 2 - Acceso Operativo y Empleados]\n";
    cout << "    +-- Zona 3: Oficinas         +-- Zona 4: Laboratorio I+D\n";
    cout << "        [PC-201 (RFID)]              [PC-202 (RFID + Teclado)]\n";
    cout << "          |                       |\n";
    cout << "          +-----------------------+\n";
    cout << "          v\n";
    cout << "  [Nivel 3 - Alta Seguridad / Boveda]\n";
    cout << "    +-- Zona 5: Sala de Servidores [PC-301 (Esclusa Biometrica)]\n";
    cout << "=====================================================\n";
    cout << "  REGLA DE FLUJO: No se permite saltar zonas no adyacentes.\n";
    cout << "  Ejemplo: Desde Pasillo Central NO se puede ir a Sala de Servidores/Boveda sin pasar por Nivel 2.\n";
    cout << "=====================================================\n";
}

inline Zona obtenerZonaPorId(int id) {
    for (const auto& z : mapaEdificio) {
        if (z.id == id) return z;
    }
    return mapaEdificio[0]; // Default Recepcion
}

inline bool esTransicionValidaEntreZonas(const string& ubicacionActual, const string& zonaDestino) {
    if (ubicacionActual == zonaDestino) return true;

    if (ubicacionActual == "Fuera del edificio") {
        return zonaDestino == "Recepcion";
    }
    if (ubicacionActual == "Recepcion") {
        return zonaDestino == "Fuera del edificio" || zonaDestino == "Pasillo Central";
    }
    if (ubicacionActual == "Pasillo Central") {
        return zonaDestino == "Recepcion" || zonaDestino == "Oficinas Administrativas" || zonaDestino == "Laboratorio I+D";
    }
    if (ubicacionActual == "Oficinas Administrativas") {
        return zonaDestino == "Pasillo Central" || zonaDestino == "Sala de Servidores";
    }
    if (ubicacionActual == "Laboratorio I+D") {
        return zonaDestino == "Pasillo Central" || zonaDestino == "Sala de Servidores";
    }
    if (ubicacionActual == "Sala de Servidores") {
        return zonaDestino == "Oficinas Administrativas" || zonaDestino == "Laboratorio I+D";
    }
    return false;
}

#endif
