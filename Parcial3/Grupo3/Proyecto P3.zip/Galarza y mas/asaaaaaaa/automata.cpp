// automata.cpp
#ifndef AUTOMATA_CPP
#define AUTOMATA_CPP

#include <iostream>
#include <string>

using namespace std;

#include "usuario.cpp"
#include "edificio.cpp"

enum Estado {
    q0_FUERA,
    q1_IDENTIFICADO,
    q2_CREDENCIA_VALIDADA,
    q3_BIOMETRIA_VERIFICADA,
    qACEPTACION_DENTRO,
    qRECHAZO_DENEGADO
};

inline string estadoToString(Estado e) {
    switch(e) {
        case q0_FUERA: return "q0 (Fuera del punto de control)";
        case q1_IDENTIFICADO: return "q1 (Identificado)";
        case q2_CREDENCIA_VALIDADA: return "q2 (Credencial Validada)";
        case q3_BIOMETRIA_VERIFICADA: return "q3 (Biometria Verificada)";
        case qACEPTACION_DENTRO: return "qACEPTACION (Acceso Permitido / Dentro)";
        case qRECHAZO_DENEGADO: return "qRECHAZO (Acceso Denegado)";
        default: return "qERROR";
    }
}

// Procesa una accion y transiciona el automata segun el estado previo, rol y permisos del usuario.
inline Estado procesarTransicion(Estado estadoActual, const string& accion, const Usuario& usr, const Zona& zona, string& explicacion) {
    switch(estadoActual) {
        case q0_FUERA:
            if (accion == "Identificarse") {
                explicacion = "Usuario ingreso credencial inicial correctamente.";
                return q1_IDENTIFICADO;
            }
            explicacion = "Accion invalida en estado inicial q0. Debe identificarse primero.";
            return qRECHAZO_DENEGADO;

        case q1_IDENTIFICADO:
            if (accion == "Tarjeta" || accion == "Credencial") {
                // 1. Validacion de Flujo de Ubicacion / Zonas Adyacentes
                if (!esTransicionValidaEntreZonas(usr.zonaActual, zona.nombre)) {
                    explicacion = "Violacion de flujo de ubicacion: No se puede acceder directamente a '" + zona.nombre + "' desde '" + usr.zonaActual + "'. Debe transitar por zonas adyacentes.";
                    return qRECHAZO_DENEGADO;
                }
                // 2. Validacion por Nivel de acceso
                if (usr.nivelMaximoPermitido < zona.nivel) {
                    explicacion = "El nivel del usuario (" + to_string(usr.nivelMaximoPermitido) + ") es inferior al nivel de la zona (" + to_string(zona.nivel) + ").";
                    return qRECHAZO_DENEGADO;
                }
                explicacion = "Credencial validada exitosamente para la zona " + zona.nombre + ".";
                return q2_CREDENCIA_VALIDADA;
            }
            explicacion = "Secuencia incorrecta. Se esperaba escanear la tarjeta o credencial.";
            return qRECHAZO_DENEGADO;

        case q2_CREDENCIA_VALIDADA:
            if (zona.puntoControl.requiereBiometria) {
                if (accion == "Huella" || accion == "Biometria") {
                    if (usr.tieneBiometria) {
                        explicacion = "Validacion biometrica exitosa en punto " + zona.puntoControl.id + ".";
                        return q3_BIOMETRIA_VERIFICADA;
                    } else {
                        explicacion = "El usuario no posee registro biometrico en el sistema.";
                        return qRECHAZO_DENEGADO;
                    }
                } else if (accion == "Abrir_Puerta") {
                    explicacion = "La zona es de alta seguridad (Nivel 3) y exige Biometria antes de abrir la puerta.";
                    return qRECHAZO_DENEGADO;
                }
            } else {
                if (accion == "Abrir_Puerta") {
                    explicacion = "Puerta desbloqueada y acceso concedido a " + zona.nombre + ".";
                    return qACEPTACION_DENTRO;
                }
            }
            explicacion = "Accion no reconocida o fuera de flujo en estado q2.";
            return qRECHAZO_DENEGADO;

        case q3_BIOMETRIA_VERIFICADA:
            if (accion == "Abrir_Puerta") {
                explicacion = "Esclusa de alta seguridad superada. Acceso concedido a " + zona.nombre + ".";
                return qACEPTACION_DENTRO;
            }
            explicacion = "Accion no valida en estado q3. Se esperaba 'Abrir_Puerta'.";
            return qRECHAZO_DENEGADO;

        case qACEPTACION_DENTRO:
            explicacion = "El usuario ya se encuentra dentro de la zona.";
            return qACEPTACION_DENTRO;

        case qRECHAZO_DENEGADO:
            explicacion = "El automata se encuentra en estado de rechazo.";
            return qRECHAZO_DENEGADO;

        default:
            explicacion = "Estado no contemplado.";
            return qRECHAZO_DENEGADO;
    }
}

#endif
