#pragma once
#include "Tramo.h"
#include <vector>
#include <string>

struct Ruta {
    std::string nombre;
    std::vector<int> idsTramos;
};

class RedTransporte {
private:
    std::vector<std::string> estaciones;
    std::vector<Tramo> tramos;
    std::vector<Ruta> rutas;

public:
    RedTransporte();
    
    int obtenerCantidadTramos() const { return tramos.size(); }

    // Gestión de red y archivos
    void agregarEstacion(const std::string& nombre);
    void agregarConexion(int orig, int dest, std::string nom, double cap, double tLibre, double costo);
    void agregarRuta(std::string nombre, std::vector<int> tramosIds);
    void mostrarRed() const;
    void mostrarRutas() const;
    
    void eliminarRuta(int idRuta);
    void eliminarEstacion(int idEstacion);
    
    bool cargarRed(const std::string& archivo);
    void guardarRed(const std::string& archivo) const;

    // Simulaciones
    void reiniciarFlujos();
    void simularComportamiento(int totalUsuarios, int criterio); 
    void simularOptimoSistema(int totalUsuarios);
    void compararEscenarios(int usuarios);
    
    // Búsquedas
    void buscarRutaMasRapida() const;
    void buscarRutaMenosCongestionada() const;
    void buscarRutaMasEconomica() const;
};