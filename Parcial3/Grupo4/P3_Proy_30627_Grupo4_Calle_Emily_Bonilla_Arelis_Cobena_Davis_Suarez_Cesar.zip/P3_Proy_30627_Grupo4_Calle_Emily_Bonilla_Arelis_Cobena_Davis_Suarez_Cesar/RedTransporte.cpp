#include "RedTransporte.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>

using namespace std;

RedTransporte::RedTransporte() {}

void RedTransporte::agregarEstacion(const string& nombre) {
    if (estaciones.size() >= 8) {
        cout << "Error: Limite maximo de 8 estaciones alcanzado.\n";
        return;
    }
    estaciones.push_back(nombre);
    cout << "Estacion agregada: [" << estaciones.size() - 1 << "] " << nombre << "\n";
}

void RedTransporte::agregarConexion(int orig, int dest, string nom, double cap, double tLibre, double costo) {
    if (orig >= estaciones.size() || dest >= estaciones.size()) {
        cout << "Error: Estaciones invalidas.\n";
        return;
    }
    tramos.push_back(Tramo(orig, dest, nom, cap, tLibre, costo));
    cout << "Conexion agregada exitosamente.\n";
}

void RedTransporte::agregarRuta(string nombre, vector<int> tramosIds) {
    rutas.push_back({nombre, tramosIds});
}

void RedTransporte::eliminarRuta(int idRuta) {
    if (idRuta < 0 || idRuta >= rutas.size()) {
        cout << "Error: ID de ruta invalido.\n";
        return;
    }
    rutas.erase(rutas.begin() + idRuta);
    cout << "Ruta eliminada correctamente.\n";
}

void RedTransporte::eliminarEstacion(int idEstacion) {
    if (idEstacion < 0 || idEstacion >= estaciones.size()) {
        cout << "Error: ID de estacion invalido.\n";
        return;
    }

    vector<int> tramosAEliminar;
    for (size_t i = 0; i < tramos.size(); i++) {
        if (tramos[i].origen == idEstacion || tramos[i].destino == idEstacion) {
            tramosAEliminar.push_back(i);
        }
    }

    for (int i = rutas.size() - 1; i >= 0; i--) {
        bool afectada = false;
        for (int idTramoRuta : rutas[i].idsTramos) {
            for (int idEliminar : tramosAEliminar) {
                if (idTramoRuta == idEliminar) afectada = true;
            }
        }
        if (afectada) rutas.erase(rutas.begin() + i);
    }

    for (int i = tramosAEliminar.size() - 1; i >= 0; i--) {
        int idEliminado = tramosAEliminar[i];
        tramos.erase(tramos.begin() + idEliminado);
        
        for (auto& ruta : rutas) {
            for (auto& idTramoRuta : ruta.idsTramos) {
                if (idTramoRuta > idEliminado) idTramoRuta--;
            }
        }
    }

    estaciones.erase(estaciones.begin() + idEstacion);
    for (auto& t : tramos) {
        if (t.origen > idEstacion) t.origen--;
        if (t.destino > idEstacion) t.destino--;
    }

    cout << "Estacion y todas sus conexiones vinculadas fueron eliminadas.\n";
}

bool RedTransporte::cargarRed(const string& archivo) {
    ifstream in(archivo);
    if (!in) return false;

    int nEstaciones;
    if (!(in >> nEstaciones)) return false; 
    
    estaciones.clear(); tramos.clear(); rutas.clear();

    for (int i = 0; i < nEstaciones; ++i) {
        string nom; in >> nom;
        estaciones.push_back(nom);
    }

    int nTramos; in >> nTramos;
    for (int i = 0; i < nTramos; ++i) {
        int orig, dest; string nom; double cap, tLibre, costo;
        in >> orig >> dest >> nom >> cap >> tLibre >> costo;
        tramos.push_back(Tramo(orig, dest, nom, cap, tLibre, costo));
    }

    int nRutas; in >> nRutas;
    for (int i = 0; i < nRutas; ++i) {
        string nom; int nIds;
        in >> nom >> nIds;
        vector<int> ids;
        for (int j = 0; j < nIds; ++j) {
            int id; in >> id;
            ids.push_back(id);
        }
        rutas.push_back({nom, ids});
    }
    in.close();
    return true;
}

void RedTransporte::guardarRed(const string& archivo) const {
    ofstream out(archivo);
    
    if (!out) {
        cout << "\n[ERROR] No se pudo escribir en el archivo txt.\n";
        return;
    }

    out << estaciones.size() << "\n";
    for (const auto& est : estaciones) out << est << "\n";

    out << tramos.size() << "\n";
    for (const auto& t : tramos) {
        out << t.origen << " " << t.destino << " " << t.nombre << " " 
            << t.capacidad << " " << t.tiempoLibre << " " << t.costo << "\n";
    }

    out << rutas.size() << "\n";
    for (const auto& r : rutas) {
        out << r.nombre << " " << r.idsTramos.size();
        for (int id : r.idsTramos) out << " " << id;
        out << "\n";
    }
    out.close();
    
    cout << "\n[INFO] Datos actualizados en el archivo txt correctamente.\n";
}

void RedTransporte::mostrarRed() const {
    cout << "\n--- ESTACIONES ---\n";
    for (size_t i = 0; i < estaciones.size(); i++) cout << "[" << i << "] " << estaciones[i] << "\n";
    
    cout << "\n--- CONEXIONES Y ESTADO ---\n";
    cout << left << setw(25) << "Conexion" << setw(10) << "Flujo" << setw(15) << "Tiempo(min)" << "Saturacion\n";
    for (const auto& t : tramos) {
        cout << left << setw(25) << t.nombre << setw(10) << t.flujoActual 
             << setw(15) << fixed << setprecision(2) << t.calcularTiempo() 
             << t.obtenerSaturacion() << " %\n";
    }
}

void RedTransporte::mostrarRutas() const {
    cout << "\n--- RUTAS DISPONIBLES ---\n";
    if (rutas.empty()) cout << "No hay rutas registradas.\n";
    for (size_t i = 0; i < rutas.size(); i++) {
        cout << "[" << i << "] " << rutas[i].nombre << "\n";
    }
}

void RedTransporte::reiniciarFlujos() {
    for (auto& tramo : tramos) tramo.flujoActual = 0;
}

void RedTransporte::simularComportamiento(int totalUsuarios, int criterio) {
    if(rutas.empty()) { cout << "No hay rutas para simular.\n"; return; }
    reiniciarFlujos();
    for (int i = 0; i < totalUsuarios; ++i) {
        int mejorRutaIdx = 0;
        double mejorValor = 1e9;
        for (size_t r = 0; r < rutas.size(); ++r) {
            double valorRuta = 0;
            double maxSaturacion = 0;
            for (int idTramo : rutas[r].idsTramos) {
                if (criterio == 1) { 
                    valorRuta += tramos[idTramo].calcularTiempo(tramos[idTramo].flujoActual + 1);
                } else if (criterio == 2) { 
                    double sat = tramos[idTramo].obtenerSaturacion(tramos[idTramo].flujoActual + 1);
                    if (sat > maxSaturacion) maxSaturacion = sat;
                } else if (criterio == 3) {
                    valorRuta += tramos[idTramo].costo;
                }
            }
            if (criterio == 2) valorRuta = maxSaturacion;
            if (valorRuta < mejorValor) { mejorValor = valorRuta; mejorRutaIdx = r; }
        }
        for (int idTramo : rutas[mejorRutaIdx].idsTramos) tramos[idTramo].flujoActual++;
    }
}

void RedTransporte::simularOptimoSistema(int totalUsuarios) {
    if(rutas.empty()) { cout << "No hay rutas para simular.\n"; return; }
    reiniciarFlujos();
    for (int i = 0; i < totalUsuarios; ++i) {
        int mejorRutaIdx = 0;
        double menorAumento = 1e9;
        for (size_t r = 0; r < rutas.size(); ++r) {
            double aumento = 0;
            for (int idTramo : rutas[r].idsTramos) {
                aumento += tramos[idTramo].calcularTiempo(tramos[idTramo].flujoActual + 1) - tramos[idTramo].calcularTiempo();
            }
            if (aumento < menorAumento) { menorAumento = aumento; mejorRutaIdx = r; }
        }
        for (int idTramo : rutas[mejorRutaIdx].idsTramos) tramos[idTramo].flujoActual++;
    }
}

void RedTransporte::buscarRutaMasRapida() const {
    if(rutas.empty()) return;
    int mejorRuta = 0; double minTiempo = 1e9;
    for (size_t r = 0; r < rutas.size(); ++r) {
        double t = 0;
        for (int id : rutas[r].idsTramos) t += tramos[id].calcularTiempo();
        if (t < minTiempo) { minTiempo = t; mejorRuta = r; }
    }
    cout << "\nRuta mas rapida actual: " << rutas[mejorRuta].nombre << " (" << minTiempo << " min)\n";
}

void RedTransporte::buscarRutaMenosCongestionada() const {
    if(rutas.empty()) return;
    int mejorRuta = 0; double minSat = 1e9;
    for (size_t r = 0; r < rutas.size(); ++r) {
        double maxS = 0;
        for (int id : rutas[r].idsTramos) {
            double s = tramos[id].obtenerSaturacion();
            if (s > maxS) maxS = s;
        }
        if (maxS < minSat) { minSat = maxS; mejorRuta = r; }
    }
    cout << "\nRuta menos congestionada actual: " << rutas[mejorRuta].nombre << " (Pico de " << minSat << "%)\n";
}

void RedTransporte::buscarRutaMasEconomica() const {
    if(rutas.empty()) return;
    int mejorRuta = 0; double minCosto = 1e9;
    for (size_t r = 0; r < rutas.size(); ++r) {
        double c = 0;
        for (int id : rutas[r].idsTramos) c += tramos[id].costo;
        if (c < minCosto) { minCosto = c; mejorRuta = r; }
    }
    cout << "\nRuta mas economica actual: " << rutas[mejorRuta].nombre << " ($" << minCosto << ")\n";
}

void RedTransporte::compararEscenarios(int usuarios) {
    if(rutas.empty()) return;
    cout << "\n--- COMPARATIVA DE ESCENARIOS (" << usuarios << " usuarios) ---\n";
    simularComportamiento(usuarios, 1);
    cout << "1. Enfoque Competitivo (Egoista - Nash):\n";
    buscarRutaMasRapida();
    simularOptimoSistema(usuarios);
    cout << "\n2. Enfoque Cooperativo (Optimo del Sistema):\n";
    buscarRutaMasRapida();
}