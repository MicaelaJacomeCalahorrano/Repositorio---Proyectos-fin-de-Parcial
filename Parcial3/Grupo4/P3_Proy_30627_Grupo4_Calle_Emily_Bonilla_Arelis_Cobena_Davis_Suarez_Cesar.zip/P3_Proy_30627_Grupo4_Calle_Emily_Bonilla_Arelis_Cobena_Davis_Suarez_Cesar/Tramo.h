#pragma once
#include <string>
#include <cmath>

struct Tramo {
    int origen;
    int destino;
    std::string nombre;
    double capacidad;
    double tiempoLibre;
    double costo;
    int flujoActual;

    Tramo(int orig, int dest, std::string nom, double cap, double tLibre, double c)
        : origen(orig), destino(dest), nombre(nom), capacidad(cap), tiempoLibre(tLibre), costo(c), flujoActual(0) {}

    double calcularTiempo(int flujoSimulado = -1) const {
        int f = (flujoSimulado == -1) ? flujoActual : flujoSimulado;
        double saturacion = (double)f / capacidad;
        return tiempoLibre * (1.0 + 0.15 * std::pow(saturacion, 4));
    }

    double obtenerSaturacion(int flujoSimulado = -1) const {
        int f = (flujoSimulado == -1) ? flujoActual : flujoSimulado;
        return ((double)f / capacidad) * 100.0;
    }
};