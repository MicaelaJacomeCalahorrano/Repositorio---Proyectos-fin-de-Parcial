#include "RedTransporte.h"
#include <iostream>
#include <string>

using namespace std;

int main() {
    RedTransporte red;
    
    string archivoDatos = "datos_red.txt";

    if (!red.cargarRed(archivoDatos)) {
        cout << "[INFO] Archivo no encontrado. Generando datos por defecto...\n";
        
        red.agregarEstacion("Casa");         // 0
        red.agregarEstacion("Universidad");  // 1
        red.agregarEstacion("Trabajo");      // 2
        red.agregarEstacion("Supermercado"); // 3

        red.agregarConexion(0, 1, "Casa->U_Principal", 500.0, 15.0, 1.50);
        red.agregarConexion(0, 1, "Casa->U_Atajo", 200.0, 25.0, 0.0);
        red.agregarConexion(0, 2, "Casa->Trabajo_Autopista", 600.0, 20.0, 3.00);
        red.agregarConexion(2, 3, "Trabajo->Super_Local", 300.0, 10.0, 0.50);

        red.agregarRuta("Ruta_Principal_U", {0});
        red.agregarRuta("Ruta_Secundaria_U", {1});
        red.agregarRuta("Ruta_Casa-Trabajo-Super", {2, 3});
        
        red.guardarRed(archivoDatos);
    } else {
        cout << "[INFO] Datos cargados exitosamente.\n";
    }

    int opcion;
    do {
        cout << "\n===== SISTEMA DE TRANSPORTE =====\n\n";
        cout << "1. Mostrar red\n";
        cout << "2. Simular usuario\n";
        cout << "3. Simular multiples usuarios\n";
        cout << "4. Buscar ruta mas rapida\n";
        cout << "5. Buscar ruta menos congestionada\n";
        cout << "6. Comparar escenarios\n";
        cout << "7. Agregar estacion (lugar)\n";
        cout << "8. Agregar conexion\n";
        cout << "9. Eliminar estacion (lugar)\n";
        cout << "10. Eliminar ruta\n";
        cout << "11. Buscar ruta mas economica\n";
        cout << "0. Salir\n";
        cout << "\nOpcion: ";
        cin >> opcion;

        switch(opcion) {
            case 1: red.mostrarRed(); red.mostrarRutas(); break;
            case 2: 
                red.simularComportamiento(1, 1);
                cout << "Simulacion de 1 usuario completada.\n";
                break;
            case 3: {
                int n, crit; 
                cout << "Cantidad de usuarios: "; cin >> n;
                cout << "Criterio (1=Tiempo, 2=Saturacion, 3=Economico): "; cin >> crit;
                red.simularComportamiento(n, crit);
                cout << "Simulacion completada.\n";
                break;
            }
            case 4: red.buscarRutaMasRapida(); break;
            case 5: red.buscarRutaMenosCongestionada(); break;
            case 6: {
                int n; cout << "Cantidad usuarios para comparar: "; cin >> n;
                red.compararEscenarios(n); 
                break;
            }
            case 7: {
                string nom; cout << "Nombre de estacion (Sin espacios): "; cin >> nom;
                red.agregarEstacion(nom);
                red.guardarRed(archivoDatos);
                break;
            }
            case 8: {
                int orig, dest; double cap, tLibre, costo; string nom;
                cout << "ID Origen: "; cin >> orig;
                cout << "ID Destino: "; cin >> dest;
                cout << "Nombre conexion (Sin espacios): "; cin >> nom;
                cout << "Capacidad (vehiculos): "; cin >> cap;
                cout << "Tiempo base (min): "; cin >> tLibre;
                cout << "Costo ($): "; cin >> costo;
                
                red.agregarConexion(orig, dest, nom, cap, tLibre, costo);
                red.agregarRuta("Ruta_Nueva_" + nom, {red.obtenerCantidadTramos() - 1}); 
                red.guardarRed(archivoDatos);
                break;
            }
            case 9: {
                red.mostrarRed();
                int id; cout << "\nIngrese el ID del LUGAR a eliminar: "; cin >> id;
                red.eliminarEstacion(id);
                red.guardarRed(archivoDatos);
                break;
            }
            case 10: {
                red.mostrarRutas();
                int id; cout << "\nIngrese el ID de la RUTA a eliminar: "; cin >> id;
                red.eliminarRuta(id);
                red.guardarRed(archivoDatos);
                break;
            }
            case 11: red.buscarRutaMasEconomica(); break;
            case 0: cout << "Saliendo...\n"; break;
            default: cout << "Opcion invalida.\n";
        }
    } while (opcion != 0);

    return 0;
}