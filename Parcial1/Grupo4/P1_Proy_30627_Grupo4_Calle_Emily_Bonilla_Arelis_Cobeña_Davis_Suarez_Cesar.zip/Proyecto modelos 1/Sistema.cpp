#include "Sistema.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <cctype>

using namespace std;

Sistema::Sistema(string archivo) : archivoTXT(archivo) {
    accesoPermitido = nullptr;
    accesoRestringido = nullptr;
    accesoDenegado = nullptr;
    topeHistorial = nullptr;
    frenteCola = nullptr;
    finCola = nullptr;
}

void Sistema::insertarLista(Nodo*& cabeza, Usuario u) {
    Nodo* nuevo = new Nodo(u);
    if (!cabeza) cabeza = nuevo;
    else {
        Nodo* aux = cabeza;
        while (aux->siguiente) aux = aux->siguiente;
        aux->siguiente = nuevo;
    }
}

void Sistema::pushPila(Usuario u) {
    Nodo* nuevo = new Nodo(u);
    nuevo->siguiente = topeHistorial;
    topeHistorial = nuevo;
}

void Sistema::enqueueCola(Usuario u) {
    Nodo* nuevo = new Nodo(u);
    if (!frenteCola) {
        frenteCola = finCola = nuevo;
    } else {
        finCola->siguiente = nuevo;
        finCola = nuevo;
    }
}

bool Sistema::pertenece(Nodo* lista, string nombre) {
    while (lista) {
        if (lista->dato.getNombre() == nombre) return true;
        lista = lista->siguiente;
    }
    return false;
}

void Sistema::guardarEnArchivo(Usuario u) {
    ofstream arch(archivoTXT, ios::app);
    if (arch.is_open()) {
        arch << u.getNombre() << "," << u.getP() << "," << u.getQ() << "," << u.getR() << "\n";
        arch.close();
    }
}

void Sistema::cargarDesdeArchivo() {
    ifstream arch(archivoTXT);
    if (!arch.is_open()) return;

    string linea, nombre, p_str, q_str, r_str;
    while (getline(arch, linea)) {
        stringstream ss(linea);
        if (getline(ss, nombre, ',') && getline(ss, p_str, ',') && 
            getline(ss, q_str, ',') && getline(ss, r_str, ',')) {
            
            bool p = stoi(p_str);
            bool q = stoi(q_str);
            bool r = stoi(r_str);
            Usuario u(nombre, p, q, r);
            clasificar(u, false); // false para no duplicar en el txt
        }
    }
    arch.close();
    cout << "Datos historicos cargados desde " << archivoTXT << ".\n";
}

void Sistema::clasificar(Usuario u, bool guardarTXT) {
    // 1. Guardar en TXT
    if (guardarTXT) guardarEnArchivo(u);

    // 2. Insertar en Pila (Historial global)
    pushPila(u);

    // 3. Insertar en Conjuntos (Listas)
    string res = u.getResultado();
    if (res == "Permitido") {
        insertarLista(accesoPermitido, u);
    } else if (res == "Restringido") {
        insertarLista(accesoRestringido, u);
        enqueueCola(u); // Insertar en Cola de revision
    } else {
        insertarLista(accesoDenegado, u);
    }
}

void Sistema::registrarUsuario() {
    string nombre;
    char opP, opQ, opR;

    cout << "\n--- REGISTRO DE USUARIO ---\n";
    cout << "Nombre del usuario: ";
    cin >> ws;
    getline(cin, nombre);

    auto validarBool = [](string msj) {
        char op;
        while (true) {
            cout << msj;
            cin >> op;
            if (toupper(op) == 'S') return true;
            if (toupper(op) == 'N') return false;
            cout << "Entrada invalida. Use S o N.\n";
        }
    };

    bool P = validarBool("[P] Credenciales validas (S/N): ");
    bool Q = validarBool("[Q] Dispositivo registrado (S/N): ");
    bool R = validarBool("[R] Dentro de horario (S/N): ");

    Usuario u(nombre, P, Q, R);
    clasificar(u, true);
    
    cout << "\nEvaluacion Logica completada: Acceso " << u.getResultado() << "\n";
}

void Sistema::imprimirConjunto(string titulo, Nodo* lista) {
    cout << "\n" << titulo << "\n";
    if (!lista) {
        cout << "  (Vacio)\n";
        return;
    }
    while (lista) {
        cout << "  - " << lista->dato.getNombre() << " [" << lista->dato.getResultado() << "]\n";
        lista = lista->siguiente;
    }
}

void Sistema::mostrarListas() {
    imprimirConjunto("=== Conjunto A (Acceso Total) ===", accesoPermitido);
    imprimirConjunto("=== Conjunto B (Acceso Restringido) ===", accesoRestringido);
    imprimirConjunto("=== Conjunto C (Bloqueados) ===", accesoDenegado);
}

void Sistema::mostrarPilaCola() {
    imprimirConjunto("=== Pila: Historial LIFO (Ultimos procesados) ===", topeHistorial);
    imprimirConjunto("=== Cola: Usuarios pendientes de revision FIFO ===", frenteCola);
}

Nodo* Sistema::interseccionLogica(Nodo* A, Nodo* B) {
    Nodo* resultado = nullptr;
    Nodo* auxA = A;
    // Si un usuario está en A y también en B (por multiples intentos)
    while (auxA) {
        if (pertenece(B, auxA->dato.getNombre()) && !pertenece(resultado, auxA->dato.getNombre())) {
            insertarLista(resultado, auxA->dato);
        }
        auxA = auxA->siguiente;
    }
    return resultado;
}

Nodo* Sistema::unionLogica(Nodo* B, Nodo* C) {
    Nodo* resultado = nullptr;
    Nodo* auxB = B;
    while (auxB) {
        if (!pertenece(resultado, auxB->dato.getNombre())) insertarLista(resultado, auxB->dato);
        auxB = auxB->siguiente;
    }
    Nodo* auxC = C;
    while (auxC) {
        if (!pertenece(resultado, auxC->dato.getNombre())) insertarLista(resultado, auxC->dato);
        auxC = auxC->siguiente;
    }
    return resultado;
}

Nodo* Sistema::diferenciaLogica(Nodo* A, Nodo* C) {
    Nodo* resultado = nullptr;
    Nodo* auxA = A;
    while (auxA) {
        // En A, pero que nunca hayan sido bloqueados en C
        if (!pertenece(C, auxA->dato.getNombre()) && !pertenece(resultado, auxA->dato.getNombre())) {
            insertarLista(resultado, auxA->dato);
        }
        auxA = auxA->siguiente;
    }
    return resultado;
}

void Sistema::mostrarConjuntos() {
    Nodo* A_int_B = interseccionLogica(accesoPermitido, accesoRestringido);
    Nodo* B_uni_C = unionLogica(accesoRestringido, accesoDenegado);
    Nodo* A_dif_C = diferenciaLogica(accesoPermitido, accesoDenegado);

    cout << "\n=== OPERACIONES LOGICAS DE CONJUNTOS ===\n";
    imprimirConjunto("A interseccion B (Usuarios con permisos en revision)", A_int_B);
    imprimirConjunto("B union C (Usuarios con limitaciones de acceso)", B_uni_C);
    imprimirConjunto("A diferencia C (Usuarios autorizados sin bloqueos historicos)", A_dif_C);
}

void Sistema::resumenFinal() {
    int totalA = 0, totalB = 0, totalC = 0, totalPila = 0;
    
    for (Nodo* a = accesoPermitido; a != nullptr; a = a->siguiente) totalA++;
    for (Nodo* b = accesoRestringido; b != nullptr; b = b->siguiente) totalB++;
    for (Nodo* c = accesoDenegado; c != nullptr; c = c->siguiente) totalC++;
    for (Nodo* p = topeHistorial; p != nullptr; p = p->siguiente) totalPila++;

    cout << "\n=== RESUMEN FINAL DE RED CORPORATIVA ===\n";
    cout << "Total de accesos procesados: " << totalPila << "\n";
    cout << "Conjunto A (Permitidos) : " << totalA << "\n";
    cout << "Conjunto B (Restringidos): " << totalB << "\n";
    cout << "Conjunto C (Denegados)   : " << totalC << "\n";
}