#pragma once
#include <string>

class Usuario {
private:
    std::string nombre;
    bool P, Q, R;
    std::string resultado;

public:
    Usuario(std::string n = "", bool p = false, bool q = false, bool r = false)
        : nombre(n), P(p), Q(q), R(r) {
        
        // Reglas de inferencia lógicas
        if (P && Q && R) {
            resultado = "Permitido";
        } else if (P && Q && !R) {
            resultado = "Restringido";
        } else {
            // Equivale a !P || !Q
            resultado = "Denegado";
        }
    }

    std::string getNombre() const { return nombre; }
    bool getP() const { return P; }
    bool getQ() const { return Q; }
    bool getR() const { return R; }
    std::string getResultado() const { return resultado; }
};

struct Nodo {
    Usuario dato;
    Nodo* siguiente;
    Nodo(Usuario u) : dato(u), siguiente(nullptr) {}
};