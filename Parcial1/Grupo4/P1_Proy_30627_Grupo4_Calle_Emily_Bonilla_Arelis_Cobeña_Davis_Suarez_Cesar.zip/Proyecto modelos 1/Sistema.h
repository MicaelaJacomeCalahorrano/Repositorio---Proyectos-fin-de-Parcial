#pragma once
#include "Modelos.h"
#include <string>

class Sistema {
private:
    // Listas para los conjuntos
    Nodo* accesoPermitido;   // Conjunto A
    Nodo* accesoRestringido; // Conjunto B
    Nodo* accesoDenegado;    // Conjunto C

    // Pila: Historial de todos los intentos (LIFO)
    Nodo* topeHistorial;     
    
    // Cola: Usuarios en revisión por acceso restringido (FIFO)
    Nodo* frenteCola;        
    Nodo* finCola;

    std::string archivoTXT;

    void insertarLista(Nodo*& cabeza, Usuario u);
    void pushPila(Usuario u);
    void enqueueCola(Usuario u);
    bool pertenece(Nodo* lista, std::string nombre);
    void guardarEnArchivo(Usuario u);

public:
    Sistema(std::string archivo);
    
    void cargarDesdeArchivo();
    void registrarUsuario();
    void clasificar(Usuario u, bool guardarTXT);
    void mostrarListas();
    void mostrarPilaCola();
    void mostrarConjuntos();
    void resumenFinal();

    // Operaciones de conjuntos
    Nodo* interseccionLogica(Nodo* A, Nodo* B);
    Nodo* unionLogica(Nodo* B, Nodo* C);
    Nodo* diferenciaLogica(Nodo* A, Nodo* C);
    void imprimirConjunto(std::string titulo, Nodo* lista);
};