#include "Controlador.h"
#include <iomanip>
#include <sstream>

void Controlador::iniciar() {
    int opcion;
    do {
        vista.mostrarMenu();
        opcion = vista.leerOpcion();

        switch (opcion) {
            case 1: {
                Estudiante estudiante = vista.leerEstudiante();
                if (repositorio.agregar(estudiante)) {
                    vista.mostrarMensaje("Estudiante agregado.");
                } else {
                    vista.mostrarMensaje("No se agrego: ya existe un estudiante con ese nombre.");
                }
                break;
            }
            case 2:
                vista.mostrarLista("TODOS LOS ESTUDIANTES", repositorio);
                break;
            case 3: {
                Estudiante* estudiante = repositorio.buscar(vista.leerNombre());
                if (estudiante != nullptr) vista.mostrarEstudiante(*estudiante);
                else vista.mostrarMensaje("No encontrado.");
                break;
            }
            case 4: {
                string nombre = vista.leerNombre();
                if (repositorio.eliminar(nombre)) {
                    conjuntoA.eliminar(nombre);
                    conjuntoB.eliminar(nombre);
                    conjuntoC.eliminar(nombre);
                    vista.mostrarMensaje("Eliminado exitosamente.");
                } else {
                    vista.mostrarMensaje("No encontrado.");
                }
                break;
            }
            case 5:
                ejecutarMotorInferencia();
                break;
            case 6:
                mostrarConjuntos();
                break;
            case 7:
                vista.mostrarResumen(repositorio.tamano(), conjuntoA.tamano(),
                                     conjuntoB.tamano(), conjuntoC.tamano());
                break;
            case 8:
                procesarRecuperacion();
                break;
            case 9:
                mostrarPrincipioConteo();
                break;
            case 10:
                mostrarCombinaciones();
                break;
            case 11:
                calcularProbabilidades();
                break;
            case 12:
                mostrarHasse();
                break;
            case 13:
                mostrarComplejidad();
                break;
            case 14:
                vista.mostrarMensaje("Programa finalizado.");
                break;
        }

        if (opcion != 14) vista.pausa();
    } while (opcion != 14);
}

void Controlador::clasificarEnConjunto(
        const Estudiante& estudiante,
        EstadoAcademico estado) {
    if (estado == APROBADO) conjuntoA.agregarFinal(estudiante);
    else if (estado == RECUPERACION) conjuntoB.agregarFinal(estudiante);
    else conjuntoC.agregarFinal(estudiante);
}

void Controlador::ejecutarMotorInferencia() {
    if (repositorio.vacia()) {
        vista.mostrarMensaje("No hay estudiantes.");
        return;
    }

    // Los conjuntos representan el estado actual, por eso se reconstruyen.
    conjuntoA.limpiar();
    conjuntoB.limpiar();
    conjuntoC.limpiar();

    Cola colaEvaluacion;
    Nodo* actual = repositorio.cabeza;
    while (actual != nullptr) {
        colaEvaluacion.encolar(&actual->dato);
        actual = actual->siguiente;
    }

    while (!colaEvaluacion.vacia()) {
        Estudiante* estudiante = colaEvaluacion.desencolar();
        EstadoAcademico nuevoEstado = deducirEstado(*estudiante);

        if (estudiante->pendienteTransicion) {
            historial.registrar(estudiante->nombre,
                                estudiante->estadoAntesCambio,
                                nuevoEstado);
            estudiante->pendienteTransicion = false;
        }

        estudiante->estadoActual = nuevoEstado;
        estudiante->evaluado = true;
        clasificarEnConjunto(*estudiante, nuevoEstado);

        vista.mostrarMensaje("\nEvaluando a: " + estudiante->nombre);
        vista.mostrarMensaje("  P (Promedio >= 7): " + string(estudiante->P() ? "V" : "F"));
        vista.mostrarMensaje("  Q (Asistencia >= 80): " + string(estudiante->Q() ? "V" : "F"));
        vista.mostrarMensaje("  R (Actividades): " + string(estudiante->R() ? "V" : "F"));
        vista.mostrarMensaje("  Resultado: " + estadoToString(nuevoEstado));
    }

    vista.mostrarMensaje("Clasificacion completada y conjuntos actualizados.");
}

void Controlador::mostrarConjuntos() {
    if (conjuntoA.tamano() + conjuntoB.tamano() + conjuntoC.tamano() == 0) {
        vista.mostrarMensaje("Primero ejecute el Motor de Inferencia.");
        return;
    }

    Lista aInterB = conjuntoA.interseccion(conjuntoB);
    Lista aUnionB = conjuntoA.unionConjuntos(conjuntoB);
    Lista noAprobados = repositorio.diferencia(conjuntoA);

    vista.mostrarLista("A INTERSECCION B (debe ser vacio)", aInterB);
    vista.mostrarLista("A UNION B (aprobados o recuperacion)", aUnionB);
    vista.mostrarLista("U - A (estudiantes que aun no aprueban)", noAprobados);

    if (aInterB.vacia()) {
        vista.mostrarMensaje("Validacion correcta: los estados son mutuamente excluyentes.");
    }
}

void Controlador::procesarRecuperacion() {
    if (conjuntoB.vacia()) {
        vista.mostrarMensaje("No hay estudiantes en recuperacion. Ejecute primero la evaluacion.");
        return;
    }

    Pila pilaRecuperacion;
    Nodo* actual = repositorio.cabeza;
    while (actual != nullptr) {
        if (actual->dato.evaluado && actual->dato.estadoActual == RECUPERACION) {
            pilaRecuperacion.apilar(&actual->dato);
        }
        actual = actual->siguiente;
    }

    vista.mostrarMensaje("\nProcesando examenes en orden LIFO...");
    while (!pilaRecuperacion.vacia()) {
        Estudiante* estudiante = pilaRecuperacion.desapilar();
        estudiante->estadoAntesCambio = estudiante->estadoActual;
        estudiante->pendienteTransicion = true;
        estudiante->promedio = vista.leerNotaRecuperacion(estudiante->nombre);
        estudiante->tareas = vista.leerTareasRecuperacion(estudiante->nombre);
        // La asistencia ya fue registrada y no se altera en el examen.
    }

    // Reevalua, registra las transiciones y actualiza todos los conjuntos.
    ejecutarMotorInferencia();
}

void Controlador::mostrarPrincipioConteo() {
    vista.mostrarMensaje("\n--- PRINCIPIO DE CONTEO ---");
    vista.mostrarMensaje("P: promedio, Q: asistencia, R: actividades.");
    vista.mostrarMensaje("Cada proposicion tiene 2 valores. Total = 2 x 2 x 2 = 2^3 = 8.\n");
    vista.mostrarMensaje("P Q R | Estado");
    vista.mostrarMensaje("---------------------------");

    int conteo[3] = {0, 0, 0};
    for (int p = 0; p <= 1; p++) {
        for (int q = 0; q <= 1; q++) {
            for (int r = 0; r <= 1; r++) {
                EstadoAcademico estado = deducirEstado(p == 1, q == 1, r == 1);
                conteo[estado]++;
                vista.mostrarMensaje(
                    string(p ? "V" : "F") + " " +
                    string(q ? "V" : "F") + " " +
                    string(r ? "V" : "F") + " | " + estadoToString(estado));
            }
        }
    }

    vista.mostrarMensaje("\nReprobado: " + to_string(conteo[REPROBADO]));
    vista.mostrarMensaje("Recuperacion: " + to_string(conteo[RECUPERACION]));
    vista.mostrarMensaje("Aprobado: " + to_string(conteo[APROBADO]));
}

int Controlador::factorial(int n) const {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int Controlador::combinacion(int n, int r) const {
    return factorial(n) / (factorial(r) * factorial(n - r));
}

void Controlador::mostrarCombinaciones() {
    vista.mostrarMensaje("\n--- COMBINACIONES DE LOS TRES REQUISITOS ---");
    vista.mostrarMensaje("El orden de cumplimiento no modifica el subconjunto obtenido.\n");

    int suma = 0;
    for (int r = 0; r <= 3; r++) {
        int resultado = combinacion(3, r);
        suma += resultado;
        vista.mostrarMensaje("C(3," + to_string(r) + ") = " + to_string(resultado));
    }

    vista.mostrarMensaje("\nC(3,0)+C(3,1)+C(3,2)+C(3,3) = " + to_string(suma));
    vista.mostrarMensaje("Subconjuntos con 2 requisitos: {P,Q}, {P,R}, {Q,R}.");
    vista.mostrarMensaje("Aunque tienen igual tamano, pueden producir estados distintos.");
}

void Controlador::calcularProbabilidades() {
    vista.mostrarMensaje("\n--- PROBABILIDAD DISCRETA ---");
    vista.mostrarMensaje("Distribucion teorica de las 8 configuraciones equiprobables:");
    vista.mostrarMensaje("P(Reprobado) = 4/8 = 0.5000 = 50.00%");
    vista.mostrarMensaje("P(Recuperacion) = 3/8 = 0.3750 = 37.50%");
    vista.mostrarMensaje("P(Aprobado) = 1/8 = 0.1250 = 12.50%");

    int evaluados = conjuntoA.tamano() + conjuntoB.tamano() + conjuntoC.tamano();
    if (evaluados > 0) {
        ostringstream salida;
        salida << fixed << setprecision(2);
        salida << "\nDistribucion observada actual:\n";
        salida << "Aprobado: " << (100.0 * conjuntoA.tamano() / evaluados) << "%\n";
        salida << "Recuperacion: " << (100.0 * conjuntoB.tamano() / evaluados) << "%\n";
        salida << "Reprobado: " << (100.0 * conjuntoC.tamano() / evaluados) << "%";
        vista.mostrarMensaje(salida.str());
    } else {
        vista.mostrarMensaje("\nNo existe una clasificacion actual. Ejecute la opcion 5.");
    }

    vista.mostrarMensaje("\nTransiciones registradas: " + to_string(historial.tamano()));
    if (historial.tamano() == 0) {
        vista.mostrarMensaje("Aun no existen cambios de estado. Procese una recuperacion.");
        return;
    }

    for (int origen = REPROBADO; origen <= APROBADO; origen++) {
        int totalOrigen = historial.contarOrigen(static_cast<EstadoAcademico>(origen));
        if (totalOrigen == 0) continue;

        vista.mostrarMensaje("\nDesde " + estadoToString(static_cast<EstadoAcademico>(origen)) +
                             " (total=" + to_string(totalOrigen) + "):");
        for (int destino = REPROBADO; destino <= APROBADO; destino++) {
            int casos = historial.contarTransicion(
                static_cast<EstadoAcademico>(origen),
                static_cast<EstadoAcademico>(destino));
            double prob = historial.probabilidad(
                static_cast<EstadoAcademico>(origen),
                static_cast<EstadoAcademico>(destino));

            ostringstream linea;
            linea << fixed << setprecision(4)
                  << "  P(" << estadoToString(static_cast<EstadoAcademico>(destino))
                  << " | " << estadoToString(static_cast<EstadoAcademico>(origen))
                  << ") = " << casos << "/" << totalOrigen << " = " << prob;
            vista.mostrarMensaje(linea.str());
        }
    }
}

void Controlador::mostrarHasse() {
    vista.mostrarMensaje("\n--- DIAGRAMA DE HASSE ---");
    vista.mostrarMensaje("E = {Reprobado, Recuperacion, Aprobado}");
    vista.mostrarMensaje("Relacion: x <= y cuando y es un nivel igual o superior a x.\n");
    vista.mostrarMensaje("        Aprobado");
    vista.mostrarMensaje("            |");
    vista.mostrarMensaje("      Recuperacion");
    vista.mostrarMensaje("            |");
    vista.mostrarMensaje("        Reprobado");

    vista.mostrarMensaje("\nPropiedades del orden:");
    vista.mostrarMensaje("1. Reflexiva: x <= x para todo estado.");
    vista.mostrarMensaje("2. Antisimetrica: si x <= y y y <= x, entonces x = y.");
    vista.mostrarMensaje("3. Transitiva: Reprobado <= Recuperacion y Recuperacion <= Aprobado");
    vista.mostrarMensaje("   implican Reprobado <= Aprobado.");
    vista.mostrarMensaje("Todos los estados son comparables; por eso tambien forman una cadena.");
    vista.mostrarMensaje("Las aristas dibujadas son relaciones de cobertura:");
    vista.mostrarMensaje("cubreA(Aprobado, Recuperacion) = " +
                         string(cubreA(APROBADO, RECUPERACION) ? "verdadero" : "falso"));
    vista.mostrarMensaje("cubreA(Recuperacion, Reprobado) = " +
                         string(cubreA(RECUPERACION, REPROBADO) ? "verdadero" : "falso"));
}

void Controlador::mostrarComplejidad() {
    vista.mostrarMensaje("\n--- COMPLEJIDAD COMPUTACIONAL ---");
    vista.mostrarMensaje("Modelo: asignacion, comparacion, avance y operacion logica = 1 OE.");
    vista.mostrarMensaje("Los coeficientes son una aproximacion; la clase asintotica no cambia.\n");

    vista.mostrarMensaje("1. Motor de inferencia para un estudiante:");
    vista.mostrarMensaje("   Tinf(1) = 16 OE = Theta(1).");

    vista.mostrarMensaje("\n2. Evaluacion de n estudiantes:");
    vista.mostrarMensaje("   Limpiar conjuntos: T1(n) = 4n + 3.");
    vista.mostrarMensaje("   Encolar punteros:  T2(n) = 7n + 2.");
    vista.mostrarMensaje("   Evaluar y clasificar: T3(n) = 24n + 1.");
    vista.mostrarMensaje("   T(n) = T1 + T2 + T3 = 35n + 6 OE.");
    vista.mostrarMensaje("   O(n), Omega(n) y Theta(n).");

    vista.mostrarMensaje("\n3. Insercion en la lista:");
    vista.mostrarMensaje("   agregarFinal usa el apuntador 'ultimo': Theta(1) por insercion.");
    vista.mostrarMensaje("   Insertar n datos ya validados: Theta(n).");
    vista.mostrarMensaje("   agregar valida nombre duplicado mediante busqueda: O(n) por alta.");

    vista.mostrarMensaje("\n4. Configuraciones:");
    vista.mostrarMensaje("   Para 3 proposiciones: 8 casos = Theta(1).");
    vista.mostrarMensaje("   Para m proposiciones: T(m) = c*2^m = Theta(2^m).");

    vista.mostrarMensaje("\n5. Probabilidad de transicion:");
    vista.mostrarMensaje("   Recorre h registros: Theta(h) tiempo y Theta(1) espacio auxiliar.");

    vista.mostrarMensaje("\n6. Diagrama de Hasse:");
    vista.mostrarMensaje("   3 vertices y 2 aristas: Theta(1).");
    vista.mostrarMensaje("   Para s estados en cadena: s vertices y s-1 aristas = Theta(s).");

    vista.mostrarMensaje("\nRelacion con el Hasse:");
    vista.mostrarMensaje("El diagrama tiene niveles fijos; aumentar estudiantes no agrega niveles.");
    vista.mostrarMensaje("Por eso clasificar cada estudiante cuesta Theta(1) y procesar n cuesta Theta(n).");
}
