#ifndef CONTROLADOR_H
#define CONTROLADOR_H

#include "../model/Modelo.h"
#include "../view/Vista.h"

class Controlador {
private:
    Vista vista;
    Lista repositorio;
    Lista conjuntoA; // Aprobados
    Lista conjuntoB; // Recuperacion
    Lista conjuntoC; // Reprobados
    HistorialTransiciones historial;

    int factorial(int n) const;
    int combinacion(int n, int r) const;
    void clasificarEnConjunto(const Estudiante& estudiante, EstadoAcademico estado);

public:
    void iniciar();
    void ejecutarMotorInferencia();
    void procesarRecuperacion();
    void mostrarConjuntos();
    void mostrarPrincipioConteo();
    void mostrarCombinaciones();
    void calcularProbabilidades();
    void mostrarHasse();
    void mostrarComplejidad();
};

#endif
