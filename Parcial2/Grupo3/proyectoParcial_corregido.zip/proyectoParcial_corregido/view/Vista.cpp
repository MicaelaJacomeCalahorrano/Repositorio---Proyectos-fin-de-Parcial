#include "Vista.h"
#include <iostream>
#include <iomanip>
#include <limits>

void Vista::mostrarMenu() {
    cout << "\n========================================\n";
    cout << "   SISTEMA DE EVALUACION ACADEMICA\n";
    cout << "========================================\n";
    cout << "1. Agregar estudiante\n";
    cout << "2. Listar todos los estudiantes\n";
    cout << "3. Buscar estudiante\n";
    cout << "4. Eliminar estudiante\n";
    cout << "5. Ejecutar Motor de Inferencia (Cola)\n";
    cout << "6. Ver Operaciones de Conjuntos\n";
    cout << "7. Ver Resumen Estadistico\n";
    cout << "8. Procesar Examen de Recuperacion (Pila)\n";
    cout << "9. Principio de Conteo\n";
    cout << "10. Combinaciones\n";
    cout << "11. Probabilidad Discreta y Transiciones\n";
    cout << "12. Diagrama de Hasse (Orden)\n";
    cout << "13. Complejidad Computacional\n";
    cout << "14. Salir\n";
    cout << "========================================\n";
}

int Vista::leerEnteroRango(const string& mensaje, int minimo, int maximo) {
    int valor;
    while (true) {
        cout << mensaje;
        if (cin >> valor && valor >= minimo && valor <= maximo) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return valor;
        }
        cout << "Valor invalido. Ingrese un numero entre " << minimo
             << " y " << maximo << ".\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

double Vista::leerDoubleRango(const string& mensaje, double minimo, double maximo) {
    double valor;
    while (true) {
        cout << mensaje;
        if (cin >> valor && valor >= minimo && valor <= maximo) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return valor;
        }
        cout << "Valor invalido. Ingrese un numero entre " << minimo
             << " y " << maximo << ".\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

int Vista::leerOpcion() {
    return leerEnteroRango("Opcion: ", 1, 14);
}

Estudiante Vista::leerEstudiante() {
    Estudiante estudiante;
    do {
        cout << "\nNombre: ";
        getline(cin, estudiante.nombre);
        if (estudiante.nombre.empty()) {
            cout << "El nombre no puede estar vacio.\n";
        }
    } while (estudiante.nombre.empty());

    estudiante.promedio = leerDoubleRango("Promedio (0-10): ", 0.0, 10.0);
    estudiante.asistencia = leerDoubleRango("Asistencia (0-100): ", 0.0, 100.0);
    estudiante.tareas = leerEnteroRango("Entrego tareas? (1=Si, 0=No): ", 0, 1) == 1;
    return estudiante;
}

string Vista::leerNombre() {
    string nombre;
    do {
        cout << "\nNombre: ";
        getline(cin, nombre);
        if (nombre.empty()) cout << "El nombre no puede estar vacio.\n";
    } while (nombre.empty());
    return nombre;
}

double Vista::leerNotaRecuperacion(const string& nombre) {
    return leerDoubleRango("Nueva nota de " + nombre + " (0-10): ", 0.0, 10.0);
}

bool Vista::leerTareasRecuperacion(const string& nombre) {
    return leerEnteroRango(
        "Completo las actividades pendientes de " + nombre + "? (1=Si, 0=No): ",
        0, 1) == 1;
}

void Vista::mostrarLista(const string& titulo, const Lista& lista) {
    cout << "\n--- " << titulo << " ---\n";
    if (lista.vacia()) {
        cout << "La lista esta vacia.\n";
        return;
    }

    Nodo* actual = lista.cabeza;
    while (actual != nullptr) {
        cout << "- " << actual->dato.nombre
             << " (Prom: " << fixed << setprecision(2) << actual->dato.promedio
             << ", Asist: " << actual->dato.asistencia << "%";
        if (actual->dato.evaluado) {
            cout << ", Estado: " << estadoToString(actual->dato.estadoActual);
        }
        cout << ")\n";
        actual = actual->siguiente;
    }
    cout << "Total: " << lista.tamano() << "\n";
}

void Vista::mostrarEstudiante(const Estudiante& estudiante) {
    cout << "\n--- ESTUDIANTE ---\n";
    cout << "Nombre: " << estudiante.nombre << "\n";
    cout << "Promedio: " << fixed << setprecision(2) << estudiante.promedio << "\n";
    cout << "Asistencia: " << estudiante.asistencia << "%\n";
    cout << "Tareas: " << (estudiante.tareas ? "Si" : "No") << "\n";
    cout << "Estado: " << (estudiante.evaluado
        ? estadoToString(estudiante.estadoActual)
        : "Sin evaluar") << "\n";
}

void Vista::mostrarMensaje(const string& mensaje) {
    cout << mensaje << "\n";
}

void Vista::pausa() {
    cout << "\nPresione Enter para continuar...";
    cin.get();
}

void Vista::mostrarResumen(int total, int aprobados, int recuperacion, int reprobados) {
    cout << "\n========================================\n";
    cout << "   RESUMEN FINAL\n";
    cout << "========================================\n";
    cout << " Total registrados : " << total << "\n";
    cout << " Aprobados (A)     : " << aprobados << "\n";
    cout << " Recuperacion (B)  : " << recuperacion << "\n";
    cout << " Reprobados (C)    : " << reprobados << "\n";
    cout << " Clasificados      : " << aprobados + recuperacion + reprobados << "\n";
    cout << "========================================\n";
}
