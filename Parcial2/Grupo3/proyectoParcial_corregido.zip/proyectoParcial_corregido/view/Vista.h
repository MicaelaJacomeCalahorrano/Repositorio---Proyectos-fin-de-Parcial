#ifndef VISTA_H
#define VISTA_H

#include "../model/Modelo.h"
#include <string>
using namespace std;

class Vista {
private:
    double leerDoubleRango(const string& mensaje, double minimo, double maximo);
    int leerEnteroRango(const string& mensaje, int minimo, int maximo);

public:
    void mostrarMenu();
    int leerOpcion();

    Estudiante leerEstudiante();
    string leerNombre();
    double leerNotaRecuperacion(const string& nombre);
    bool leerTareasRecuperacion(const string& nombre);

    void mostrarLista(const string& titulo, const Lista& lista);
    void mostrarEstudiante(const Estudiante& estudiante);
    void mostrarMensaje(const string& mensaje);
    void pausa();
    void mostrarResumen(int total, int aprobados, int recuperacion, int reprobados);
};

#endif
