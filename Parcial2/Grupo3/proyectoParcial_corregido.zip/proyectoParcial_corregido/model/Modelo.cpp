#include "Modelo.h"
#include <utility>

bool esEstadoMejorOIgual(EstadoAcademico nuevoEstado, EstadoAcademico estadoAnterior) {
    return nuevoEstado >= estadoAnterior;
}

bool cubreA(EstadoAcademico superior, EstadoAcademico inferior) {
    return static_cast<int>(superior) == static_cast<int>(inferior) + 1;
}

EstadoAcademico deducirEstado(bool p, bool q, bool r) {
    if (p && q && r) {
        return APROBADO;
    }
    if ((!p && q) || (p && q && !r)) {
        return RECUPERACION;
    }
    return REPROBADO;
}

EstadoAcademico deducirEstado(const Estudiante& estudiante) {
    return deducirEstado(estudiante.P(), estudiante.Q(), estudiante.R());
}

string estadoToString(EstadoAcademico estado) {
    if (estado == APROBADO) return "Aprobado";
    if (estado == RECUPERACION) return "Recuperacion";
    return "Reprobado";
}

// ---------------- LISTA ----------------
Lista::Lista() : ultimo(nullptr), cantidad(0), cabeza(nullptr) {}

void Lista::copiarDesde(const Lista& otra) {
    Nodo* actual = otra.cabeza;
    while (actual != nullptr) {
        agregarFinal(actual->dato);
        actual = actual->siguiente;
    }
}

Lista::Lista(const Lista& otra) : ultimo(nullptr), cantidad(0), cabeza(nullptr) {
    copiarDesde(otra);
}

Lista& Lista::operator=(const Lista& otra) {
    if (this != &otra) {
        Lista copia(otra);
        swap(cabeza, copia.cabeza);
        swap(ultimo, copia.ultimo);
        swap(cantidad, copia.cantidad);
    }
    return *this;
}

Lista::Lista(Lista&& otra) noexcept
    : ultimo(otra.ultimo), cantidad(otra.cantidad), cabeza(otra.cabeza) {
    otra.cabeza = nullptr;
    otra.ultimo = nullptr;
    otra.cantidad = 0;
}

Lista& Lista::operator=(Lista&& otra) noexcept {
    if (this != &otra) {
        limpiar();
        cabeza = otra.cabeza;
        ultimo = otra.ultimo;
        cantidad = otra.cantidad;
        otra.cabeza = nullptr;
        otra.ultimo = nullptr;
        otra.cantidad = 0;
    }
    return *this;
}

Lista::~Lista() {
    limpiar();
}

bool Lista::agregar(const Estudiante& estudiante) {
    if (buscar(estudiante.nombre) != nullptr) {
        return false;
    }
    agregarFinal(estudiante);
    return true;
}

void Lista::agregarFinal(const Estudiante& estudiante) {
    Nodo* nuevo = new Nodo{estudiante, nullptr};
    if (cabeza == nullptr) {
        cabeza = nuevo;
        ultimo = nuevo;
    } else {
        ultimo->siguiente = nuevo;
        ultimo = nuevo;
    }
    cantidad++;
}

bool Lista::eliminar(const string& nombre) {
    Nodo* anterior = nullptr;
    Nodo* actual = cabeza;

    while (actual != nullptr && actual->dato.nombre != nombre) {
        anterior = actual;
        actual = actual->siguiente;
    }

    if (actual == nullptr) {
        return false;
    }

    if (anterior == nullptr) {
        cabeza = actual->siguiente;
    } else {
        anterior->siguiente = actual->siguiente;
    }

    if (actual == ultimo) {
        ultimo = anterior;
    }

    delete actual;
    cantidad--;
    return true;
}

Estudiante* Lista::buscar(const string& nombre) {
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        if (actual->dato.nombre == nombre) {
            return &actual->dato;
        }
        actual = actual->siguiente;
    }
    return nullptr;
}

const Estudiante* Lista::buscar(const string& nombre) const {
    const Nodo* actual = cabeza;
    while (actual != nullptr) {
        if (actual->dato.nombre == nombre) {
            return &actual->dato;
        }
        actual = actual->siguiente;
    }
    return nullptr;
}

int Lista::tamano() const {
    return cantidad;
}

bool Lista::vacia() const {
    return cabeza == nullptr;
}

void Lista::limpiar() {
    while (cabeza != nullptr) {
        Nodo* borrar = cabeza;
        cabeza = cabeza->siguiente;
        delete borrar;
    }
    ultimo = nullptr;
    cantidad = 0;
}

Lista Lista::interseccion(const Lista& otra) const {
    Lista resultado;
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        if (otra.buscar(actual->dato.nombre) != nullptr) {
            resultado.agregarFinal(actual->dato);
        }
        actual = actual->siguiente;
    }
    return resultado;
}

Lista Lista::diferencia(const Lista& otra) const {
    Lista resultado;
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        if (otra.buscar(actual->dato.nombre) == nullptr) {
            resultado.agregarFinal(actual->dato);
        }
        actual = actual->siguiente;
    }
    return resultado;
}

Lista Lista::unionConjuntos(const Lista& otra) const {
    Lista resultado;
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        resultado.agregarFinal(actual->dato);
        actual = actual->siguiente;
    }

    actual = otra.cabeza;
    while (actual != nullptr) {
        if (resultado.buscar(actual->dato.nombre) == nullptr) {
            resultado.agregarFinal(actual->dato);
        }
        actual = actual->siguiente;
    }
    return resultado;
}

// ---------------- PILA ----------------
Pila::Pila() : tope(nullptr) {}

Pila::~Pila() {
    limpiar();
}

void Pila::apilar(Estudiante* estudiante) {
    NodoReferencia* nuevo = new NodoReferencia{estudiante, tope};
    tope = nuevo;
}

Estudiante* Pila::desapilar() {
    if (vacia()) return nullptr;
    NodoReferencia* borrar = tope;
    Estudiante* estudiante = borrar->dato;
    tope = tope->siguiente;
    delete borrar;
    return estudiante;
}

bool Pila::vacia() const {
    return tope == nullptr;
}

void Pila::limpiar() {
    while (!vacia()) {
        desapilar();
    }
}

// ---------------- COLA ----------------
Cola::Cola() : frente(nullptr), final(nullptr) {}

Cola::~Cola() {
    limpiar();
}

void Cola::encolar(Estudiante* estudiante) {
    NodoReferencia* nuevo = new NodoReferencia{estudiante, nullptr};
    if (vacia()) {
        frente = nuevo;
        final = nuevo;
    } else {
        final->siguiente = nuevo;
        final = nuevo;
    }
}

Estudiante* Cola::desencolar() {
    if (vacia()) return nullptr;
    NodoReferencia* borrar = frente;
    Estudiante* estudiante = borrar->dato;
    frente = frente->siguiente;
    if (frente == nullptr) {
        final = nullptr;
    }
    delete borrar;
    return estudiante;
}

bool Cola::vacia() const {
    return frente == nullptr;
}

void Cola::limpiar() {
    while (!vacia()) {
        desencolar();
    }
}

// ---------------- HISTORIAL ----------------
HistorialTransiciones::HistorialTransiciones()
    : cabeza(nullptr), ultimo(nullptr), cantidad(0) {}

HistorialTransiciones::~HistorialTransiciones() {
    limpiar();
}

void HistorialTransiciones::registrar(
        const string& nombre,
        EstadoAcademico anterior,
        EstadoAcademico actual) {
    NodoTransicion* nuevo = new NodoTransicion{{nombre, anterior, actual}, nullptr};
    if (cabeza == nullptr) {
        cabeza = nuevo;
        ultimo = nuevo;
    } else {
        ultimo->siguiente = nuevo;
        ultimo = nuevo;
    }
    cantidad++;
}

int HistorialTransiciones::contarOrigen(EstadoAcademico origen) const {
    int total = 0;
    NodoTransicion* actual = cabeza;
    while (actual != nullptr) {
        if (actual->dato.anterior == origen) total++;
        actual = actual->siguiente;
    }
    return total;
}

int HistorialTransiciones::contarTransicion(
        EstadoAcademico origen,
        EstadoAcademico destino) const {
    int total = 0;
    NodoTransicion* actual = cabeza;
    while (actual != nullptr) {
        if (actual->dato.anterior == origen && actual->dato.actual == destino) {
            total++;
        }
        actual = actual->siguiente;
    }
    return total;
}

int HistorialTransiciones::tamano() const {
    return cantidad;
}

double HistorialTransiciones::probabilidad(
        EstadoAcademico origen,
        EstadoAcademico destino) const {
    int totalOrigen = contarOrigen(origen);
    if (totalOrigen == 0) return 0.0;
    return static_cast<double>(contarTransicion(origen, destino)) / totalOrigen;
}

void HistorialTransiciones::limpiar() {
    while (cabeza != nullptr) {
        NodoTransicion* borrar = cabeza;
        cabeza = cabeza->siguiente;
        delete borrar;
    }
    ultimo = nullptr;
    cantidad = 0;
}
