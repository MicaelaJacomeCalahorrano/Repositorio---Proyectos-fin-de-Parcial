#ifndef MODELO_H
#define MODELO_H

#include <string>
using namespace std;

// Orden academico: REPROBADO <= RECUPERACION <= APROBADO
enum EstadoAcademico { REPROBADO = 0, RECUPERACION = 1, APROBADO = 2 };

bool esEstadoMejorOIgual(EstadoAcademico nuevoEstado, EstadoAcademico estadoAnterior);
bool cubreA(EstadoAcademico superior, EstadoAcademico inferior);
string estadoToString(EstadoAcademico estado);

struct Estudiante {
    string nombre;
    double promedio = 0.0;
    double asistencia = 0.0;
    bool tareas = false;

    EstadoAcademico estadoActual = REPROBADO;
    EstadoAcademico estadoAntesCambio = REPROBADO;
    bool evaluado = false;
    bool pendienteTransicion = false;

    bool P() const { return promedio >= 7.0; }
    bool Q() const { return asistencia >= 80.0; }
    bool R() const { return tareas; }
};

EstadoAcademico deducirEstado(const Estudiante& estudiante);
EstadoAcademico deducirEstado(bool p, bool q, bool r);

struct Nodo {
    Estudiante dato;
    Nodo* siguiente;
};

class Lista {
private:
    Nodo* ultimo;
    int cantidad;
    void copiarDesde(const Lista& otra);

public:
    Nodo* cabeza;

    Lista();
    Lista(const Lista& otra);
    Lista& operator=(const Lista& otra);
    Lista(Lista&& otra) noexcept;
    Lista& operator=(Lista&& otra) noexcept;
    ~Lista();

    bool agregar(const Estudiante& estudiante);       // valida duplicados
    void agregarFinal(const Estudiante& estudiante);  // O(1), para datos ya validados
    bool eliminar(const string& nombre);
    Estudiante* buscar(const string& nombre);
    const Estudiante* buscar(const string& nombre) const;
    int tamano() const;
    bool vacia() const;
    void limpiar();

    Lista interseccion(const Lista& otra) const;
    Lista diferencia(const Lista& otra) const;
    Lista unionConjuntos(const Lista& otra) const;
};

// La cola y la pila guardan punteros a estudiantes del repositorio.
struct NodoReferencia {
    Estudiante* dato;
    NodoReferencia* siguiente;
};

class Pila {
private:
    NodoReferencia* tope;

public:
    Pila();
    ~Pila();
    void apilar(Estudiante* estudiante);
    Estudiante* desapilar();
    bool vacia() const;
    void limpiar();
};

class Cola {
private:
    NodoReferencia* frente;
    NodoReferencia* final;

public:
    Cola();
    ~Cola();
    void encolar(Estudiante* estudiante);
    Estudiante* desencolar();
    bool vacia() const;
    void limpiar();
};

struct RegistroTransicion {
    string nombre;
    EstadoAcademico anterior;
    EstadoAcademico actual;
};

struct NodoTransicion {
    RegistroTransicion dato;
    NodoTransicion* siguiente;
};

class HistorialTransiciones {
private:
    NodoTransicion* cabeza;
    NodoTransicion* ultimo;
    int cantidad;

public:
    HistorialTransiciones();
    ~HistorialTransiciones();
    void registrar(const string& nombre, EstadoAcademico anterior, EstadoAcademico actual);
    int contarOrigen(EstadoAcademico origen) const;
    int contarTransicion(EstadoAcademico origen, EstadoAcademico destino) const;
    int tamano() const;
    double probabilidad(EstadoAcademico origen, EstadoAcademico destino) const;
    void limpiar();
};

#endif
