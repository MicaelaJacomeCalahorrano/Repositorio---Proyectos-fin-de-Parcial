#pragma once
#include "Modelos.h"
#include "Analizadores.h"
#include <string>

class Sistema {
private:
    Nodo* accesoPermitido;
    Nodo* accesoRestringido;
    Nodo* accesoDenegado;
    Nodo* topeHistorial;
    Nodo* frenteCola;
    Nodo* finCola;
    std::string archivoTXT;

    AnalizadorEstadistico analistaEstadistico;
    AnalizadorEstructural analistaEstructural;

    void insertarLista(Nodo*& cabeza, Usuario u);
    void pushPila(Usuario u);
    void enqueueCola(Usuario u);
    bool pertenece(Nodo* lista, std::string nombre);
    void guardarEnArchivo(Usuario u);

public:
    Sistema(std::string archivo);
    
    void cargarDesdeArchivo();
    void registrarUsuario();
    void clasificar(Usuario u, bool guardarTXT);
    void mostrarListas();
    void mostrarPilaCola();
    void mostrarConjuntos();
    void resumenFinal();

    Nodo* interseccionLogica(Nodo* A, Nodo* B);
    Nodo* unionLogica(Nodo* B, Nodo* C);
    Nodo* diferenciaLogica(Nodo* A, Nodo* C);
    void imprimirConjunto(std::string titulo, Nodo* lista);

    void analizarConteoYPermutaciones();
    void calcularProbabilidadesYDemostrar();
    void mostrarDiagramaHasse();
    void analizarComplejidad();
};