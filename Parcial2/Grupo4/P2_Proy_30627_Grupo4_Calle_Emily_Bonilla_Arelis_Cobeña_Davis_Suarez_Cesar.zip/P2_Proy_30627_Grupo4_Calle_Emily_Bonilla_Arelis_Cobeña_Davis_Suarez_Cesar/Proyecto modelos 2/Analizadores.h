#pragma once
#include <iostream>

class AnalizadorEstadistico {
public:
    void analizarConteoYPermutaciones();
    void calcularProbabilidadesYDemostrar(int totalA, int totalB, int totalC, int totalPila);
};

class AnalizadorEstructural {
public:
    void mostrarDiagramaHasse();
    void analizarComplejidad();
};