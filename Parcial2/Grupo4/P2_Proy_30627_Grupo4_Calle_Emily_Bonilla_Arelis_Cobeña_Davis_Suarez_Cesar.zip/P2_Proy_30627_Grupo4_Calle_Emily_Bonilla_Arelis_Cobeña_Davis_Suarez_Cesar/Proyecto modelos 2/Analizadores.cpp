#include "Analizadores.h"

using namespace std;

void AnalizadorEstadistico::analizarConteoYPermutaciones() {
    cout << "\n=== CONTEO Y PERMUTACIONES ===\n";
    cout << "Principio de Multiplicacion:\n";
    cout << "- Tenemos 3 variables lógicas (P, Q, R), cada una con 2 estados posibles (V/F).\n";
    cout << "- Combinaciones totales posibles = 2 * 2 * 2 = 8 combinaciones.\n\n";
    
    cout << "Permutaciones (Orden de validacion):\n";
    cout << "- El orden en que se validan P, Q y R genera P(3) = 3! = 6 permutaciones.\n";
    cout << "- Conclusion: Dado que los operadores AND (&&) y OR (||) cumplen con la\n";
    cout << "  propiedad conmutativa, el orden de validacion NO influye en el resultado final.\n";
}

void AnalizadorEstadistico::calcularProbabilidadesYDemostrar(int totalA, int totalB, int totalC, int totalPila) {
    cout << "\n=== PROBABILIDAD DISCRETA Y DEMOSTRACION DIRECTA ===\n";
    if (totalPila == 0) {
        cout << "El espacio muestral es 0. Registra usuarios primero.\n";
        return;
    }

    cout << "Espacio muestral (Total de accesos): " << totalPila << "\n";
    cout << "- P(Permitido)   = " << totalA << " / " << totalPila << " (" << ((float)totalA / totalPila) * 100 << "%)\n";
    cout << "- P(Restringido) = " << totalB << " / " << totalPila << " (" << ((float)totalB / totalPila) * 100 << "%)\n";
    cout << "- P(Denegado)    = " << totalC << " / " << totalPila << " (" << ((float)totalC / totalPila) * 100 << "%)\n\n";

    cout << "Demostracion Directa (Regla de Acceso Permitido):\n";
    cout << "Hipotesis: P(V) ^ Q(V) ^ R(V)\n";
    cout << "Tesis: Acceso = Permitido\n";
    cout << "Demostracion: Asumiendo que el usuario tiene credenciales validas (P=V), un dispositivo\n";
    cout << "registrado (Q=V) y esta en horario (R=V). La operacion (V ^ V ^ V) evalua a Verdadero.\n";
    cout << "Por lo tanto, la condicion del bloque 'Permitido' se cumple. (Q.E.D.)\n";
}

void AnalizadorEstructural::mostrarDiagramaHasse() {
    cout << "\n=== RELACIONES DE ORDEN Y DIAGRAMA DE HASSE ===\n";
    cout << "Relacion de orden (<=): 'Nivel restrictivo que precede a un nivel permisivo'\n";
    cout << "Jerarquia estructurada: Denegado <= Restringido <= Permitido\n\n";
    cout << "           [ Permitido ]       <-- Mas permisivo (P ^ Q ^ R)\n";
    cout << "                 |\n";
    cout << "                 |\n";
    cout << "         [ Restringido ]       <-- Intermedio (P ^ Q ^ ~R)\n";
    cout << "                 |\n";
    cout << "                 |\n";
    cout << "           [ Denegado ]        <-- Mas restrictivo (~P v ~Q)\n";
}

void AnalizadorEstructural::analizarComplejidad() {
    cout << "\n=== ANALISIS DE COMPLEJIDAD TEMPORAL Y ESPACIAL ===\n";
    cout << "1. Complejidad Temporal (Tiempo):\n";
    cout << "   - Insercion y evaluacion: O(N) en el peor caso al insertar al final.\n";
    cout << "   - Operaciones logicas: O(N^2) debido a los bucles anidados.\n\n";
    cout << "2. Complejidad Espacial (Memoria):\n";
    cout << "   - O(N), donde N es el numero total de usuarios procesados.\n\n";
    cout << "Relacion con el Diagrama de Hasse:\n";
    cout << "El algoritmo fragmenta el espacio O(N) en 3 subconjuntos mutuamente excluyentes,\n";
    cout << "reduciendo los tiempos de busqueda especifica dentro de cada nivel de autorizacion.\n";
}