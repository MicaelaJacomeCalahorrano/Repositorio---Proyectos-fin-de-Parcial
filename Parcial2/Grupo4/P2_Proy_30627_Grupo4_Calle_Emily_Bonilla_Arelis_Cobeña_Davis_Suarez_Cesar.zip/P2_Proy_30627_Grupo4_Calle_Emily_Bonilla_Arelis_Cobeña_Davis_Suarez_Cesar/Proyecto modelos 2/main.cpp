#include "Sistema.h"
#include <iostream>

using namespace std;

int main() {
    Sistema redCorporativa("usuarios.txt");
    redCorporativa.cargarDesdeArchivo();

    int opcion;
    do {
        cout << "\n====== NETSECURE S.A. ======\n";
        cout << "1. Registrar e Inferir Acceso\n";
        cout << "2. Mostrar Conjuntos Base (A, B, C)\n";
        cout << "3. Mostrar Historial (Pila) y Cola de Revision\n";
        cout << "4. Mostrar Operaciones Logicas de Conjuntos\n";
        cout << "5. Resumen Final\n";
        cout << "6. Analizar Combinaciones y Permutaciones de Acceso\n";
        cout << "7. Calcular Probabilidades Discretas y Demostracion Directa\n";
        cout << "8. Mostrar Jerarquia (Relaciones de Orden y Diagrama de Hasse)\n";
        cout << "9. Analisis de Complejidad del Algoritmo\n";
        cout << "0. Salir\n";
        cout << "Opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1: redCorporativa.registrarUsuario(); break;
            case 2: redCorporativa.mostrarListas(); break;
            case 3: redCorporativa.mostrarPilaCola(); break;
            case 4: redCorporativa.mostrarConjuntos(); break;
            case 5: redCorporativa.resumenFinal(); break;
            case 6: redCorporativa.analizarConteoYPermutaciones(); break;
            case 7: redCorporativa.calcularProbabilidadesYDemostrar(); break;
            case 8: redCorporativa.mostrarDiagramaHasse(); break;
            case 9: redCorporativa.analizarComplejidad(); break;
            case 0: cout << "Saliendo del sistema...\n"; break;
            default: cout << "Opcion invalida.\n";
        }
    } while (opcion != 0);

    return 0;
}